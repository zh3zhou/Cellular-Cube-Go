## 目标
- 增加设置 UI：按 ESC 打开/关闭；W/S 移动选项，A/D 调整值；光标高亮当前项；每项显示进度条或开关状态。
- 参数项：FPS、Wu Di Mode（无敌）、Reward 开关、Survival Ramp（可选）。
- 背景遮罩与 PAUSE 保持一致（使用 `GameConfig.UI_OVERLAY_ALPHA`）。

## 交互与显示
- 打开/关闭：ESC 进入/退出设置。
- 选择移动：W/S 在选项间上下移动；当前项高亮（光标框或颜色加亮）。
- 数值调整：A/D 左右调整，显示进度条（0–100%）与当前数值。
- 操作说明：面板底部显示 `W/S选择 | A/D调整 | Enter/Space切换开关 | P暂停 | R重开 | ESC退出`。

## 参数映射
- FPS（滑条）：范围 [5, 60]；进度条随值变化；应用于 `GameConfig.FPS`（渲染用 `clock.tick`）。
- Wu Di Mode（开关）：布尔型；显示 ON/OFF；在碰撞检测早期判断，启用时忽略所有碰撞。
- Reward System（开关）：布尔型；显示 ON/OFF；对应 `GameConfig.REWARD_SYSTEM_ENABLED`。
- Survival Ramp（滑条，可选）：`GameConfig.SURVIVAL_RAMP_FRAMES` 显示/调整，默认 1000（注意调整幅度与提示）。

## 技术实现
- 引擎（`src/core/game_engine.py`）
  - 新增 `self.show_settings` 状态与当前选项索引；ESC 切换设置模式；设置模式禁用玩家移动与 CA 更新，仅处理 UI 输入与渲染。
  - `_render` 在设置模式下绘制半透明遮罩（用 PAUSE 的 alpha/颜色），调用新 `UI.render_settings(...)`。
- 输入（`src/utils/input_utils.py`）
  - 新增 `handle_settings_input(engine)`：处理 W/S 移动、A/D 调整、Enter/Space 切换布尔项；对 FPS/Survival Ramp 做边界限制与步进。
- UI（`src/graphics/ui.py`）
  - 新增 `render_settings(engine, items, selected_index)`：
    - 标题“SETTINGS”；列表按行显示：名称、当前值/开关；右侧绘制进度条（按值比例）；当前项用高亮框。
    - 使用与 PAUSE 一致的字体与颜色（`font_large/font_small`、`PAUSE_COLOR`），背景遮罩强度与 PAUSE 相同。

## 碰撞与无敌
- 在 `_check_collisions` 顶部判断 `Wu Di Mode`（布尔标志），为真则直接跳过碰撞逻辑；命名严格使用“Wu Di Mode”。

## 验证
- 进入设置：能用 W/S 移动选项；FPS 与 Survival Ramp 用 A/D 调节并实时更新进度条与数值；Wu Di Mode/Reward 能用 Enter/Space 切换。
- Wu Di Mode 生效：开启后玩家与细胞不 Game Over；关闭后恢复正常。
- FPS 调整后帧率稳定；退出设置后恢复游戏流程。

## 注意与回退
- 所有调整为运行时修改，不改写配置文件；若异常可 ESC 退出设置恢复游戏。
- 对数值型参数加边界与步进（FPS 每次 ±1；Survival Ramp 每次 ±50）以防抖动。

如果确认，我将按此方案实现，并在三处（引擎/输入/UI）完成集成与验证。