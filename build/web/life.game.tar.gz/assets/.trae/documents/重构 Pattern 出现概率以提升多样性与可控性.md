## 目标
- 结合尺寸分层+类型配额（A）与自适应均衡（B），提升多样性与可控性。
- 部分实施生存驱动（D）：生存时间越长，逐步提升稀有图案的出现权重或增强A/B的作用强度，带上限。
- 清理冗余配置与未用方法，保留你的自有库并允许手动编辑。

## 代码改动范围
- `config/pattern_config.py`：新增与合并参数，移除重复定义。
- `src/patterns/pattern_library.py`：在加载阶段为图案注入类型字段（启发式），不修改外部 JSON 结构。
- `src/patterns/pattern_generator.py`：重写权重选择逻辑，新增窗口计数与生存影响强度，清理未用方法。

## 详细实现步骤
1. 配置合并与新增
- 合并唯一的基础系数定义，移除重复：`BASE_WEIGHT_MULTIPLIER`、`SIZE_DIVERSITY_FACTOR`、`MAX_PATTERN_BIAS`（参考 `config/pattern_config.py:15–20` 与 `44–49`）。
- 新增：
  - `TYPE_QUOTAS = {"spaceship":0.25, "oscillator":0.25, "still_life":0.2, "gun":0.05, "other":0.25}`
  - `WINDOW_SIZE = 200`
  - `QUOTA_GAIN = 0.6`
  - `INV_FREQ_ALPHA = 0.5`（自适应均衡强度）
  - `RARE_THRESHOLD = 0.15`、`SURVIVAL_RARE_MAX_BOOST = 0.5`
  - `SURVIVAL_STRENGTH_MAX = 1.0`（用于增强 A/B 的强度上限）

2. 图案类型识别（保持 JSON 不变）
- 在 `PatternLibrary` 加载时，为每个图案名称计算 `type`：
  - `spaceship`：含 `glider|lwss|mwss|hwss|spaceship`
  - `gun`：含 `gun|glider_gun`
  - `oscillator`：含 `blinker|pulsar|toad|clock|figure_eight|pentadecathlon`
  - `still_life`：含 `block|beehive|loaf|boat|tub|barge|pond|snake|ship|aircraft_carrier`
  - 其他归为 `other`
- 将 `type` 附加在内存结构中：`{'pattern': [...], 'probability': p, 'type': t}`。

3. 选择器重构（A+B+D 部分）
- 在 `PatternGenerator`：
  - 新增 `self._history = deque(maxlen=PatternConfig.WINDOW_SIZE)` 持久记录最近选择（size, type, name）。
  - 在 `_calculate_size_probabilities` 中引入尺寸逆频修正：`inv_size = 1 / sqrt(1 + alpha * count(size))`，乘在现有权重上；保留近期尺寸惩罚与差异奖励（`src/patterns/pattern_generator.py:102–166`）。
  - 替换 `_select_pattern_non_repeating` 为“动态权重选择”：对候选名计算
    - `base = probability`
    - `quota_boost = max(0, TYPE_QUOTAS[type] - window_ratio(type)) * QUOTA_GAIN`
    - `recency_mult`：保持近期去重与惩罚（尺寸内队列）
    - `rare_boost`：当 `base < RARE_THRESHOLD` 时按当前 `survival_scale` 计算，最多 `SURVIVAL_RARE_MAX_BOOST`
    - 最终：`w = max(ε, base) * inv_size * (1 + quota_boost) * recency_mult * (1 + rare_boost)`
  - 选中后更新 `self._history` 与尺寸、类型计数。
  - 新增 `set_survival_scale(scale: float)`，用于外部设置生存影响强度，内部裁剪到 `[0, SURVIVAL_STRENGTH_MAX]`。

4. 冗余清理
- 移除未用：`_select_pattern_by_probability`（`src/patterns/pattern_generator.py:182–199`）。
- 移除弃用：`_kill_pattern_area`（`src/patterns/pattern_generator.py:86–101`）。
- 配置文件保留唯一版本的系数定义，删除重复块。
- 如需，`get_classic_patterns`（`src/patterns/pattern_library.py:755–765`）改为从当前库派生以避免静态不一致。

5. 验证与调参
- 编写离线模拟：在不渲染的条件下运行 10k 次选择，输出尺寸/类型直方图、窗口熵、短时重复率，确保达到 `TYPE_QUOTAS` 与均衡目标。
- 默认参数建议：
  - 稳健版：`QUOTA_GAIN=0.6`、`INV_FREQ_ALPHA=0.5`、`WINDOW_SIZE=200`、`RECENCY_LAST_PENALTY=0.5`
  - 进取版：`QUOTA_GAIN=0.9`、`INV_FREQ_ALPHA=0.8`、`WINDOW_SIZE=300`
  - 保守版：`QUOTA_GAIN=0.3`、`INV_FREQ_ALPHA=0.3`、`WINDOW_SIZE=100`

## 生存驱动（D 的两种部分实现选项）
- 稀有加权型：`rare_boost = survival_scale * k`，仅对 `probability < RARE_THRESHOLD` 生效，封顶 `SURVIVAL_RARE_MAX_BOOST`。
- 强度增强型：随 `survival_scale` 线性增强 `QUOTA_GAIN` 与 `INV_FREQ_ALPHA`，封顶在 `SURVIVAL_STRENGTH_MAX`。

## 交付
- 合并后的配置、重构后的选择器代码、类型识别、验证脚本与统计输出。

是否按此计划实施？我将开始编码、清理与验证。